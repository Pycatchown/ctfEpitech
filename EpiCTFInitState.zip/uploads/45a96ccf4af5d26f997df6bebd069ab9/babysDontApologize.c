#include <stdlib.h>
#include <stdio.h>

void cl0s3d_cupb04rd(int cup, int sp00n)
{
    int (*c0ff3)(char *) = &system;

    if (cup && sp00n)
        (int)c0ff3("/bin/sh");
}

int main(void)
{
    char apologie[123];

    setvbuf(stdout, NULL, _IONBF, 0);
	setvbuf(stdin, NULL, _IONBF, 0);
    puts("You lied to me at the previous step. So I closed the cupboard with the coffe inside.");
    puts("I'm waiting for your apologie.");

    gets(apologie);

    return (0);
}